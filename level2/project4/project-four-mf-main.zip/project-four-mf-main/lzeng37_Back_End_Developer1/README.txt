README for Team Project Four (CS400 @ UW Madison)
==================================================

Every member of a team must have an individual README.txt file filled in in their folder on
the team's GitHub repo.

Name of submitting team member: Linxiu Zeng
Wisc email of submitting team member: lzeng37@wisc.edu
Team name: MF
Role of submitting team member: Back End Developer
TA: Harit
Lecturer: Florian Heimerl

Contributions Week 1:
---------------------
Passage.java
passageInterface.java
RedBlackTree.java


Contributions Week 2:
---------------------
Passage.java
passageInterface.java
I finished all the method draft within these two java files. 
Some more adjustments and debuggings are required. 

Contributions Week 3:
---------------------
New written file:
RBT.java

And I make some more revise and add comment to:
Passage.java
passageInterface.java
passageTest.java
Makefile
Ensuring every uploaded file can work properly

Files written by me:
--------------------
Passage.java
passageInterface.java
RBT.java
RedBlackTree.java

Files submitted with this project that were developed in an earlier project:
----------------------------------------------------------------------------
RedBlackTree.java

Web address at which the program is available:
----------------------------------------------
<If you and your team have written a web app that is available on the internet,
replace this text with its address. This is not a requirement of Project Four
and you will not loose points for not implementing a web application or for not
having a running version on the web.>

Additional notes about the submission:
--------------------------------------
<List any additional notes for the grader here (only required by the final deadline).>

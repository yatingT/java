README for Team Project Four (CS400 @ UW Madison)
==================================================

Every member of a team must have an individual README.txt file filled in in their folder on
the team's GitHub repo.

Name of submitting team member: Yating Tian
Wisc email of submitting team member: ytian83@wisc.edu
Team name: MF
Role of submitting team member: Back End Developer
TA: Harit
Lecturer: Gary

Contributions Week 1:
---------------------
Went to data world and other data set website to find the dataset
participated the team meeting
talked about how we start the peoject with other team member
created the repository for this project
downloaded the start files for this project. 

Contributions Week 2:
---------------------
participated the team meeting
talked about how we start the project with other team member

Passage.java
PassageInterface.java
RedBlackTree.java

Contributions Week 3:
---------------------
participated the team meeting
updated:
Passage.java
PassageInterface.java
created:
RBT.java
finish debugging for my teammates.


Files written by me:
--------------------
<List ALL of the source files here that were written by you. Note that each of the
files must contain correct file headers, including your name, team, and role. List
files one per line in this section of the README. Only complete this section with
your final week 3 submission of project four.>
Passage.java
PassageInterface.java
RedBlackTree.java
RBT.java


Files submitted with this project that were developed in an earlier project:
----------------------------------------------------------------------------
RedBlackTree.java

Web address at which the program is available:
----------------------------------------------
<If you and your team have written a web app that is available on the internet,
replace this text with its address. This is not a requirement of Project Four
and you will not loose points for not implementing a web application or for not
having a running version on the web.>

Additional notes about the submission:
--------------------------------------
<List any additional notes for the grader here (only required by the final deadline).>
